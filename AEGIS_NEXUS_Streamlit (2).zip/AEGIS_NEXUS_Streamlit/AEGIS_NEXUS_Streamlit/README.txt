AEGIS NEXUS Streamlit dashboard

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Connect your laptop to the ESP8266 Wi-Fi access point (AEGIS-NEXUS).
5. Run: streamlit run app.py
6. Use http://192.168.4.1 as the ESP base URL.

The app reads GET /api from the ESP8266 firmware and plots sensor history in memory.
If it cannot connect, test http://192.168.4.1/api in a browser while connected to the ESP hotspot.
The API should return temperature, humidity, gasRaw, distanceCm, status fields and messages.
MQ raw values are not ppm. Demonstration thresholds are not certified life-safety limits.
