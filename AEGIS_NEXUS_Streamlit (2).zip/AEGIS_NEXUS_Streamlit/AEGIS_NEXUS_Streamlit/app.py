import time
from datetime import datetime
import requests
import pandas as pd
import streamlit as st

st.set_page_config(page_title="AEGIS NEXUS", page_icon="🌐", layout="wide")
st.markdown("""
<style>
.stApp{background:radial-gradient(circle at 75% 0%,#10243b 0,#07111e 42%,#050a12 100%);color:#eaf3ff}
.block-container{padding-top:1.2rem;max-width:1500px}
[data-testid="stMetric"]{background:linear-gradient(145deg,#112235,#08121f);border:1px solid #263b53;padding:16px 18px;border-radius:16px}
[data-testid="stMetricLabel"]{color:#9bb2c9}
</style>
""", unsafe_allow_html=True)

st.markdown("<div style='color:#8fa8c1;letter-spacing:.14em;font-size:.75rem;font-weight:700'>STANDALONE ENVIRONMENTAL MONITORING</div><h1 style='letter-spacing:.08em'>AEGIS <span style='color:#53d8ff'>NEXUS</span></h1><p style='color:#9bb2c9'>Live sensor telemetry · ESP8266 access point · Local network</p>", unsafe_allow_html=True)

if "history" not in st.session_state:
    st.session_state.history = []

with st.sidebar:
    st.header("Connection")
    base_url = st.text_input("ESP8266 base URL", "http://192.168.4.1").strip().rstrip("/")
    auto_refresh = st.toggle("Auto-refresh every 2 seconds", True)
    st.divider()
    st.subheader("Fallback thresholds")
    temp_warn = st.number_input("Temperature warning °C", value=50.0)
    temp_danger = st.number_input("Temperature danger °C", value=60.0)
    gas_warn = st.number_input("MQ raw warning", min_value=0, max_value=1023, value=600)
    gas_danger = st.number_input("MQ raw danger", min_value=0, max_value=1023, value=750)
    dist_warn = st.number_input("Distance warning cm (≤)", min_value=0.0, value=20.0)
    dist_danger = st.number_input("Distance danger cm (≤)", min_value=0.0, value=10.0)
    if st.button("Clear history", use_container_width=True):
        st.session_state.history = []
        st.rerun()

def num(d, key):
    try:
        v = float(d.get(key))
        return v if pd.notna(v) else None
    except (TypeError, ValueError):
        return None

def classify(v, warning, danger, distance=False):
    if v is None or (distance and v < 0):
        return "SENSOR ERROR"
    if distance:
        return "DANGER" if v <= danger else "WARNING" if v <= warning else "NORMAL"
    return "DANGER" if v >= danger else "WARNING" if v >= warning else "NORMAL"

try:
    r = requests.get(f"{base_url}/api", timeout=3)
    r.raise_for_status()
    data = r.json()
except Exception as e:
    st.error(f"Cannot connect to {base_url}/api: {e}")
    st.info("Connect your laptop to the ESP8266 Wi-Fi hotspot (AEGIS-NEXUS), then test http://192.168.4.1/api in your browser.")
    st.stop()

temp = num(data, "temperature")
humidity = num(data, "humidity")
gas = num(data, "gasRaw")
distance = num(data, "distanceCm")

def firmware_status(key, value, warning, danger, distance_mode=False):
    s = data.get(key)
    if s in ("NORMAL", "WARNING", "DANGER", "SENSOR ERROR"):
        return s
    return classify(value, warning, danger, distance_mode)

ts = firmware_status("temperatureStatus", temp, temp_warn, temp_danger)
hs = data.get("humidityStatus", classify(humidity, 80, 90))
gs = firmware_status("gasStatus", gas, gas_warn, gas_danger)
ds = firmware_status("ultrasonicStatus", distance, dist_warn, dist_danger, True)
statuses = [ts, hs, gs, ds]
overall = "DANGER" if "DANGER" in statuses else "WARNING" if any(s in ("WARNING", "SENSOR ERROR") for s in statuses) else "NORMAL"

a, b, c = st.columns([1, 1, 2])
with a:
    if overall == "DANGER": st.error("🔴 DANGER")
    elif overall == "WARNING": st.warning("🟠 WARNING / CHECK SENSORS")
    else: st.success("🟢 NORMAL")
with b:
    st.metric("Device", "ONLINE")
with c:
    st.info(f"Network: ESP access point · IP: {data.get('ip', '192.168.4.1')} · Updated: {datetime.now().strftime('%H:%M:%S')}")

messages = data.get("messages", [])
if isinstance(messages, str): messages = [messages]
for msg in messages:
    if overall == "DANGER": st.error(msg)
    elif overall == "WARNING": st.warning(msg)

st.subheader("Live sensor readings")
cols = st.columns(4)
cols[0].metric("🌡️ Temperature", "--" if temp is None else f"{temp:.1f} °C", ts)
cols[1].metric("💧 Humidity", "--" if humidity is None else f"{humidity:.1f} %", str(hs))
cols[2].metric("≋ MQ gas (raw)", "--" if gas is None or gas < 0 else f"{gas:.0f}", gs)
cols[3].metric("〰️ Ultrasonic distance", "--" if distance is None or distance < 0 else f"{distance:.1f} cm", ds)

st.subheader("Sensor trends")
st.session_state.history.append({
    "Time": datetime.now(),
    "Temperature (°C)": temp,
    "Humidity (%)": humidity,
    "MQ gas raw": gas if gas is not None and gas >= 0 else None,
    "Distance (cm)": distance if distance is not None and distance >= 0 else None,
})
st.session_state.history = st.session_state.history[-120:]
df = pd.DataFrame(st.session_state.history).set_index("Time")
left, right = st.columns(2)
with left:
    st.markdown("**Temperature & humidity**")
    cols = [c for c in ["Temperature (°C)", "Humidity (%)"] if c in df and df[c].notna().any()]
    if cols: st.line_chart(df[cols], height=260)
    else: st.caption("Waiting for valid readings.")
with right:
    st.markdown("**MQ gas & ultrasonic distance**")
    cols = [c for c in ["MQ gas raw", "Distance (cm)"] if c in df and df[c].notna().any()]
    if cols: st.line_chart(df[cols], height=260)
    else: st.caption("Waiting for valid readings.")

with st.expander("Raw ESP8266 API response"):
    st.json(data)

st.caption("AEGIS NEXUS prototype · MQ values are raw ADC readings, not ppm. Thresholds are demonstration settings, not certified safety limits.")
if auto_refresh:
    time.sleep(2)
    st.rerun()
